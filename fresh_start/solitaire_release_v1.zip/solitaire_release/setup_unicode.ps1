[Console]::InputEncoding = [Console]::OutputEncoding = $OutputEncoding =
>>   [System.Text.Utf8Encoding]::new()